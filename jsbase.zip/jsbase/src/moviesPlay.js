// main.js
let data;

import('./moviesPlay.js')
    .then(module => {
        console.log('Data imported into data constant');
        data = module;
        run();
    });

function run() {
    // Accessing movies and other exports from moviesPlay.js
    const movies = data.movies;
    const languages = data.languages;
    const countries = data.countries;
    const genres = data.genres;

    // Accessing the getCounts function
    const counts = data.getCounts();

    console.log('Number of movies: ' + counts.movies);
    console.log('Number of Hindi movies: ' + counts.hindiMovies);
    console.log('Number of languages: ' + counts.languages);
    console.log('Number of countries: ' + counts.countries);
    console.log('Number of genres: ' + counts.genres);

    // You can still iterate through the movies array if needed
    for (let i = 0; i < movies.length; i++) {
        console.log(movies[i].originalLanguage);
    }
}

// Define displayCompanyInfo function
function displayCompanyInfo() {
    // Your function logic here
    console.log('Displaying company info');
}
